For the latest information regarding Convert, go to 
http://www.joshmadison.com/software.

If you find Convert useful, send me an email at josh@joshmadison.com
letting me know what country you're from, and what you're using
it for.

Disclaimer
----------
Convert is Freeware (even for commercial use), and as such,
you should not have been charged to obtain this software.
You may redistribute Convert as long as it is not modified
in any way. Convert is provided "as is" and I can not be
responsible for any damage that may occur by using this
software.  This includes the information contained in it.